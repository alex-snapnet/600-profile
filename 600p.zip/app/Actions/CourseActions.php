<?php 

namespace App\Actions;

use App\Actions\Base\BaseAction;

class CourseActions extends BaseAction{
    

    protected $rpp = 2;

    
    function onInput($model)
    {
      
    }

    function onDuplicate($model)
    {
        return false;
    }

    function onDuplicateMessage()
    {
        return '';
    }

    function onIndex($model)
    {
      
    }


}