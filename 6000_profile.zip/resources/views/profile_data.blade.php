@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Company Profile (<b style="color: blue;">{{ $company['company'] }}</b>)</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif


                    @foreach ($fields as $field)

                    <div class="row">

                        <div class="col-md-2">
                            <label for="">

                                <b>{{ ucwords(str_replace("_"," ",$field)) }} : </b>


                            </label>
                        </div>

                        <div class="col-md-8">
                                <label for="">
                                        {{ $company[$field] }}
                                </label>
                        </div>

                    </div>

                    @endforeach



                </div>
            </div>
        </div>
    </div>
</div>
@endsection
