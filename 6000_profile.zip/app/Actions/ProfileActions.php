<?php

namespace App\Actions;

use App\Actions\Base\BaseAction;

class ProfileActions extends BaseAction{

    protected $rpp = 20;
    protected $filters = [];



     function onDuplicate($model)
     {
         return false;
     }

     function onDuplicateMessage()
     {
         return '';
     }

     function onIndex($model,$filters=[])
     {

        $this->filters = [];

        if (!empty($filters)){

            $sqlQuery = '';
            $andQuery = [];

            foreach ($filters as $k=>$filter){

                $andQuery[] = $this->decodeFilterValue($k,$filter);

            }

            $sqlQuery = implode(' and ' , $andQuery);

            $model = $model->whereRaw($sqlQuery);

          $this->filters = $filters;

        }

        return $model;
     }

     function decodeFilterValue($key,$filter){

       $r = explode(' ',$filter);
       $r = implode('_spc_',$r);
       $r = explode('-',$r);
       $r = implode('_spc_',$r);
       $r = explode('_spc_',$r);
       $rr = [];

       foreach ($r as $k=>$v){
           $rr[] = $key . " like '%" . $v . "%' ";
       }

       $rr[] = $key . " like '%" . $filter . "%' ";

       return ' (' . implode(' or ' , $rr) . ') ';
     }

     function onInput($model)
     {

     }

     function onGetFields($model)
     {
         return [
             'company','incorporation','start_date','business','category','head_office','city','ppp','telephone','mobile','fax','email','alternate_email','md_ceo','admin_hr','employees','share_capital','turnover','auditors','solicitors','business_contact','admin_contact','corporate_contact'
         ];
     }

     function hasFilters(){
        //  print_r($this->filters);
       return !empty($this->filters);
     }

     function filterGetQuery($request=[]){

         $r = $this->filters;
         $rr = [];
         foreach ($r as $k=>$v){
          $rr[] = "criteria[" . $k . "]=" . $v;
         }

         foreach ($request as $k=>$v){
             if (!is_array($v)){
                $rr[] = $k . '=' . $v;
             }
         }

         return "?" . implode('&',$rr);

     }




}
