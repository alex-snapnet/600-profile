<?php 

namespace App\Actions;

use App\Material;
use Illuminate\Http\Request;
use App\Actions\Base\BaseAction;

class MaterialActions extends BaseAction{

     
    function onInput($model)
    {
       $this->handleUploads($model);      
    }

    private function handleUploads(Material $material){

    }

    function onIndex($model)
    {
      
    }   

    function onDuplicate($model)
    {
        return false;
    }

    function onDuplicateMessage()
    {
        return '';
    }


}