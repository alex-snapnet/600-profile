<?php 

namespace App\Actions;

use App\UserMaterial;
use Illuminate\Http\Request;

use App\Actions\Base\BaseAction;

use App\User;
use App\Material;

class UserMaterialActions extends BaseAction{

    
    function onDuplicate($model)
    {
      return false;
    }

    function onDuplicateMessage()
    {
      return '';
    }

    function onInput($model)
    {    
      $this->doUpload($model); 
    }

    function onIndex($model)
    {
      
    }

    private function doUpload($model){

    }


  
   
    // function store(User $user,Material $material,UserMaterial $userMaterial,Request $request){
    //   $userMaterial->material_id = $material->id; 
    //   // $this->getInput($request,$userMaterial);
    //   return [
    //     'data'=>$user->user_materials()->save($userMaterial),
    //     'message'=>'User material created'
    //   ];
    // }

    // function index(){
    //    return [
    //      'data'=>UserMaterial::all()
    //    ];
    // }

    // function update(UserMaterial $userMaterial,Request $request){
    //   // $this->getInput($request,$userMaterial);
    //   return [
    //     'data'=>$userMaterial->save(),
    //     'message'=>"User Material saved"
    //   ];
    // }

    // function destroy(UserMaterial $userMaterial){
    //   return [
    //     'data'=>$userMaterial->delete(),
    //     'message'=>'User Material removed'
    //   ];
    // }

    // function show(UserMaterial $userMaterial){
    //  return [
    //    'data'=>$userMaterial
    //  ];
    // }

}