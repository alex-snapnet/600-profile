<?php

namespace App\Actions;

use App\Actions\Base\BaseAction;

class ProfileActions extends BaseAction{

    protected $rpp = 20;
    protected $filters = [];



     function onDuplicate($model)
     {
         return false;
     }

     function onDuplicateMessage()
     {
         return '';
     }

     function onIndex($model,$filters=[])
     {

        $this->filters = [];

        if (!empty($filters)){

            foreach ($filters as $k=>$filter){
                if ($k == 0){
                    $model = $model->where($k, 'like', '%' . $filter . '%');
                  }else{
                    $model = $model->where($k, 'like', '%' . $filter . '%');
                  }
            }

          $this->filters = $filters;

        }

        return $model;
     }

     function onInput($model)
     {

     }

     function onGetFields($model)
     {
         return [
             'company','incorporation','start_date','business','category','head_office','city','ppp','telephone','mobile','fax','email','alternate_email','md_ceo','admin_hr','employees','share_capital','turnover','auditors','solicitors','business_contact','admin_contact','corporate_contact'
         ];
     }

     function hasFilters(){
        //  print_r($this->filters);
       return !empty($this->filters);
     }

     function filterGetQuery(){
         $r = $this->filters;
         $rr = [];
         foreach ($r as $k=>$v){
          $rr[] = $k . "=" . $v;
         }
         return "?" . implode('&',$rr);
     }




}
