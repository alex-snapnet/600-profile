<div class="container">

   <div class="row">


       <div class="col-md-12">

       <?php
          //print_r(session()->all());
       ?>

         <!-- <form enctype="multipart/form-data" method="post" action="<?php echo e(route('home.importcsv')); ?>">
           <?php echo csrf_field(); ?>
          <div class="form-group">
              <label for="">
                  Select Excel Document (.csv)
              </label>
              <input type="file" id="csv_file" name="csv_file" />
              <input type="hidden" name="bin" id="bin" />
          </div>

          <div class="form-group">
              <button class="btn btn-sm btn-success">Import csv Document</button>
          </div>


         </form> -->

         <script>

function getBase64(file,cb) {
   var reader = new FileReader();
   reader.readAsDataURL(file);
   reader.onload = function () {
     console.log(reader.result);
     cb(reader.result);
   };
   reader.onerror = function (error) {
     console.log('Error: ', error);
     cb(error);
   };
}

(function($){
    $(function(){

       $('#csv_file').on('change',function(){

        //    console.log($(this).get(0).files[0]);
        getBase64($(this).get(0).files[0],function(bin){
            $('#bin').val(bin);
        });

       });


    });
})(jQuery);

// var file = document.querySelector('#files > input[type="file"]').files[0];
// getBase64(file);

         </script>


       </div>

       <div class="col-md-12">
       <form method="get" action="<?php echo e(route('home')); ?>">

          <div class="row">

           <div class="col-md-4" style="display: inline-block;">
                <div class="form-group">
                    <label for="">Select Category</label>
                    
                <select name="column_filter" class="form-control" id="column_filter">
                        <option value="*">-Global Search-</option>
                        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($field); ?>"><?php echo e($field); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
               </div>


               

               <div class="col-md-2" style="padding: 0;">
                    <div class="form-group">
                            <label for="">&nbsp;</label>
                            <button class="btn btn-sm btn-info form-control" style="color: #fff;/* font-weight: bold; */font-size: 17px;">Filter</button>
                    </div>
                <!-- <button class="btn btn-sm btn-warning"> + </button>    -->
               </div>

               <?php if($hasFilters): ?>
               <div class="col-md-2">
                    <div class="form-group">
                            <label for="">&nbsp;</label>
                            <a href="<?php echo e(route('home.exportcsv') . $filterGetQuery); ?>" class="btn btn-success form-control">Export To Excel</a>
                    </div>
               </div>
               <?php endif; ?>

               <div class="col-md-12" id="column_filter_list" style="
               border: 1px solid cornflowerblue;
               padding: 7px;
               border-radius: 11px;
               margin-bottom: 11px;
               display:none;
           "></div>

            </div>

               <div class="col-md-6" align="right">

               </div>

           </form>

       </div>


       <div class="col-md-12">
           <div class="col-md-6">
            <?php echo e($data['data']->links()); ?>

           </div>
       </div>




       <div class="col-md-12" style="padding: 0;">

         <table class="table table-bordered table-striped">


         <tr>
             <th>
                 ID
             </th>
             <th>
                 Company
             </th>
             <th>
                 Category
             </th>
             <th>
                 Options
             </th>
         </tr>

         <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <tr>
             <td>
                 <?php echo e($v->id); ?>

             </td>
             <td>
                 <?php echo e($v->company); ?>

             </td>
             <td>

                 <?php echo e($v->category); ?>

             </td>
             <td>
                 <a target="_blank" href="<?php echo e(route('company.profile',[$v->id])); ?>" class="btn btn-sm btn-warning">Detail</a>
             </td>
         </tr>


         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


         </table>


       </div>

       <?php echo e($data['data']->links()); ?>






    </div>
</div>

<script>

 (function($){


    //  alert('jQuery Loaded.');
    var $column_filter_list = $('#column_filter_list');

    $('[data-select]').each(function(){
        $(this).val($(this).data('select'));
    });


    $('#column_filter').on('change',function(){
        // alert('alert...');
      var key = $(this).val();
      addFilter(key);

    });

    function addFilter(key,val){
        val = val || '';
        $column_filter_list.show();
        $column_filter_list.append('<span id="cnt' + key + '"><input style="margin: 5px;text-align: center " placeholder="' + key + '" type="text" value="' + val + '" name="criteria[' + key + ']" /><button data-remove="cnt' + key + '" type="button">&cross;</button></span>');
        bindRemove();
        // handleEmptyFilter();
    }

    <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      addFilter('<?php echo e($key); ?>','<?php echo e($filter); ?>');
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    function bindRemove(){
       $('[data-remove]').each(function(){
           if (!$(this).data('remove-bound')){
              $(this).data('remove-bound',true);
              var key = $(this).data('remove');
              $(this).on('click',function(){

                // alert('#cnt' + key);

                 $('#' + key).remove();

                 handleEmptyFilter();

              });

           }
       });
    }


    function handleEmptyFilter(){
        console.log($('[data-remove]').length);
        if ($('[data-remove]').length <= 0){
        $column_filter_list.hide();
      }
    }


 })(jQuery);

</script>
<?php /**PATH C:\code\6000-profiles\resources\views/profile/profile_table.blade.php ENDPATH**/ ?>