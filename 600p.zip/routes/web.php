<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::post('/home-import-csv','HomeController@importCsv')->name('home.importcsv')->middleware('auth');

Route::get('/home-export-csv','HomeController@exportToCsv')->name('home.exportcsv')->middleware('auth');


Route::get('/company-profile/{company}','HomeController@getCompanyProfile')->name('company.profile')->middleware('auth');
// Route::get('/company-search','HomeController@companySearch')->name('home.company_search')->middleware('auth');
