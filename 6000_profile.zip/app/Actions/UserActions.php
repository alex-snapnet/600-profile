<?php 

namespace App\Actions;

use App\User;
use App\Actions\Base\BaseAction;


class UserActions extends BaseAction{

     
    function onInput($model)
    {
      
    }

    function onIndex($model)
    {
      
    }

    function onDuplicate($model)
    {
        return false;
    }

    function onDuplicateMessage()
    {
        return '';
    }



}