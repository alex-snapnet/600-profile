<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Actions\ProfileActions;
use App\Company;

class HomeController extends Controller
{
    private $profileActions;

    public function __construct(ProfileActions $profileActions, Request $request)
    {
        $this->middleware('auth');
        $this->profileActions = $profileActions;
        $this->profileActions->init($request);
    }

    private function getFilters(Request $request){

        $search_text = '';
        $column_filter = '';
        //criteria[admin_contact]

        if ($request->has('column_filter')){
            $column_filter = $request->column_filter;
        }

        if ($request->has('search_text')){
            $search_text = $request->search_text;
        }

        if ($request->has('criteria')){
            $filters = $request->criteria;
        }else{
            $filters = [];
        }

    //     [
    //         'search_text'=>$search_text,
    //         'column_filter'=>$column_filter
    //  ];

        return $filters;
    }

    public function index(Company $company,Request $request)
    {

        $column_filter = '*';
        $search_text = '';
        if ($request->has('column_filter')){
         $column_filter = $request->column_filter;
        }
        if ($request->has('search_text')){
         $search_text = $request->search_text;
        }



        $filters = $this->getFilters($request);

        // $filters = [
        //     'search_text'=>$search_text,
        //     'column_filter'=>$column_filter
        // ];

        // print_r($filters);

        // Profile $profile
        return view('home', [
            'fields' => $this->profileActions->onGetFields($company),
            'data'=>$this->profileActions->index($company,$filters),
            'search_text'=>$search_text,
            'column_filter'=>$column_filter,
            'hasFilters'=>$this->profileActions->hasFilters(),
            'filterGetQuery'=>$this->profileActions->filterGetQuery(),
            'filters'=>$filters
        ]);

    }

    function getCompanyProfile(Company $company){
      return view('profile_data',[
          'company'=>$company,
          'fields'=>$this->profileActions->onGetFields($company)
      ]);
    }


    function exportToCsv(Company $company,Request $request){
        $filters = $this->getFilters($request);
        return $this->profileActions->exportToCsv($company,$filters);
    }

    function importCsv(Company $company)
    {
        // $data = $this->profileActions->importCsv(Company::class);
        // print_r($data);
        // dd('ok');
        // return $data;
        // return redirect(route('home'))->with('data', $data);
    }
}
