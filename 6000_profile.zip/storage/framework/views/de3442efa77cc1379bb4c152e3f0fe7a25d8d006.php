<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Company Profile (<b style="color: blue;"><?php echo e($company['company']); ?></b>)</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


                    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="row">

                        <div class="col-md-2">
                            <label for="">

                                <b><?php echo e(ucwords(str_replace("_"," ",$field))); ?> : </b>


                            </label>
                        </div>

                        <div class="col-md-8">
                                <label for="">
                                        <?php echo e($company[$field]); ?>

                                </label>
                        </div>

                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\code\6000-profiles\resources\views/profile_data.blade.php ENDPATH**/ ?>