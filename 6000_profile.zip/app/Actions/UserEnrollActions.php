<?php 

namespace App\Actions;

use App\User;
use App\Actions\Base\BaseAction;

use App\UserEnroll;

class UserEnrollActions extends BaseAction{

    function onInput($model)
    {
      
    }

    function onDuplicate($model)
    {
      $email = $this->request->email;
      return ($model::where('email',$email)->count() > 0);
    }

    function onDuplicateMessage()
    {
      return  'An account with this e-mail already exists!';
    }

    function onIndex($model)
    {
      
    }     

   
    // function store(User $user,UserEnroll $userEnroll,Request $request){
    //   $this->getInput($request,$userEnroll);
    //   return [
    //     'data'=>$user->user_enrolls()->save($userEnroll),
    //     'message'=>'User enroll created'
    //   ];
    // }


}