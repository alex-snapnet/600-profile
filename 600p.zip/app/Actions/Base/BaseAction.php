<?php

namespace App\Actions\Base;

use Excel;

abstract class BaseAction{

    protected $model = null;
    protected $request = null;
    protected $rpp = 5;
    protected $csvData = [];



    function init($request)
    {
        $this->request = $request;
    }

    abstract function onInput($model);

    private function getInput($model){
       $this->onInput($model);
       $dt = $this->request->all();
       foreach ($dt as $k=>$v){
          $model->$k = $v;
       }
    }


    function store($model){
      if (!$this->onDuplicate($model)){
        return $this->save($model,'Created');
      }else{
        return [
          'message'=>$this->onDuplicateMessage(),
          'error'=>true
        ];
      }
    }

    function update($model){
      return $this->save($model,'Saved');
    }

    private function save($model,$message = 'Created'){
      $this->getInput($model);
      return [
          'data'=>$model->save(),
          'message'=>$message
      ];
    }

    function destroy($model){
      return [
          'data'=>$model->delete(),
          'message'=>'Removed'
      ];
    }


    abstract function onDuplicate($model);
    abstract function onDuplicateMessage();
    abstract function onIndex($model,$filters);
    abstract function onGetFields($model);



    function index($model,$filters=[]){
      $model = $this->onIndex($model,$filters);
      return [
          'data'=>$model->paginate($this->rpp)
      ];
    }

    private function getRaw($model){

    }

    private function getColumns($model){

    }

    function exportToCsv($model,$filters=[]){
      $model = $this->onIndex($model,$filters);
      $data = $model->get();
      return $data;
    }


    function prepareJSON($input) {

      //This will convert ASCII/ISO-8859-1 to UTF-8.
      //Be careful with the third parameter (encoding detect list), because
      //if set wrong, some input encodings will get garbled (including UTF-8!)
      // $imput = mb_convert_encoding($input, 'UTF-8', 'ASCII,UTF-8,ISO-8859-1');
      //Remove UTF-8 BOM if present, json_decode() does not like it.
      // if(substr($input, 0, 3) == pack("CCC", 0xEF, 0xBB, 0xBF)) $input = substr($input, 3);
     //

      // $input = explode('\ufeff',$input);
      // $input = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $input);
      $input = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $input);
      // $input = implode('',$input);

      return $input;

  }




    function importCsv($class){

      ini_set('memory_limit','256M');

      $bin = $this->request->bin;
      $sep = 'data:application/vnd.ms-excel;base64,';
      $bin = explode($sep,$bin);
      $bin = $bin[1];

      $bin = trim($bin);
      // $bin = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $bin);
      $bin = $this->prepareJSON($bin);

      $bin = base64_decode($bin);
      $bin = explode(PHP_EOL,$bin);
      $bin = array_map('str_getcsv',$bin);
      // $bin = $bin[0];

      $header = $bin[0];
      // // unset($bin[0]);
      array_shift($bin);

      $data = [];

      foreach ($bin as $k1=>$v){
        $colsData = [];
        foreach ($header as $k2=>$col){
          if (isset($v[$k2])){
            $colsData[$this->prepareJSON($col) ] = $v[$k2];
          }else{
            $colsData[$this->prepareJSON($col) ] = $k2;
          }
        }
        $data[] = $colsData;
        $colsData = [];
      }

      // \ufeff

      foreach ($data as $record){
        $objInsert = new $class;
        foreach ($record as $field=>$value){
          $field = trim($field);
          $objInsert->$field = $value;
        }
        $objInsert->save();
      }


      // $bin = str_getcsv($bin);

      // $bin = explode("\n\r",$bin);

      // print_r($this->request->csv_file->store('csv'));


      // $response = [];

      $response[] = $data;

      // $response[] = $bin;

      return $response;

    }

    function show($model){
      return [
          'data'=>$model
      ];
    }


}
